Unit tests still missing

Documentation in Example Files